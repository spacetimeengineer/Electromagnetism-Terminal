## SimShell.gd — In-game command console.
## Toggle with backtick (`). Disengages sim keys while open.

extends CanvasLayer

var sim: Node = null

var shell_panel: PanelContainer
var vbox: VBoxContainer
var output_label: RichTextLabel
var input_line: LineEdit

var shell_open: bool = false
var prev_backtick: bool = false

var history: PackedStringArray = []
var history_idx: int = -1
const MAX_HISTORY := 64
const MAX_OUTPUT_LINES := 200
var output_lines: PackedStringArray = []

var schedule_queue: Array[Dictionary] = []


func _ready() -> void:
	sim = _find_simulator(get_tree().root)
	_build_ui()
	_set_shell_visible(false)


func _process(delta: float) -> void:
	var bt := Input.is_key_pressed(KEY_QUOTELEFT)
	if bt and not prev_backtick:
		shell_open = not shell_open
		_set_shell_visible(shell_open)
	prev_backtick = bt

	# Schedule processing
	if sim and sim.has_method("get_sim_time") and not schedule_queue.is_empty():
		var t: float = sim.get_sim_time()
		var fired := []
		for i in range(schedule_queue.size()):
			if schedule_queue[i]["time"] <= t: fired.append(i)
		for i in range(fired.size() - 1, -1, -1):
			_exec_command(schedule_queue[fired[i]]["cmd"], true)
			schedule_queue.remove_at(fired[i])


func _unhandled_input(event: InputEvent) -> void:
	if not shell_open: return
	if event is InputEventKey and event.pressed:
		if event.keycode == KEY_UP:
			if history.size() > 0:
				history_idx = clampi(history_idx - 1, 0, history.size() - 1)
				input_line.text = history[history_idx]
				input_line.caret_column = input_line.text.length()
			get_viewport().set_input_as_handled()
		elif event.keycode == KEY_DOWN:
			if history.size() > 0:
				history_idx = clampi(history_idx + 1, 0, history.size())
				input_line.text = history[history_idx] if history_idx < history.size() else ""
				input_line.caret_column = input_line.text.length()
			get_viewport().set_input_as_handled()
		elif event.keycode == KEY_ESCAPE:
			shell_open = false; _set_shell_visible(false)
			get_viewport().set_input_as_handled()


func _build_ui() -> void:
	var fs := 13
	shell_panel = PanelContainer.new()
	shell_panel.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	shell_panel.position = Vector2(12, -270)
	shell_panel.grow_vertical = Control.GROW_DIRECTION_BEGIN
	shell_panel.custom_minimum_size = Vector2(600, 260)
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.04, 0.05, 0.04, 0.88)
	sb.border_color = Color(0.25, 0.35, 0.25, 0.5)
	sb.set_border_width_all(1); sb.set_corner_radius_all(4); sb.set_content_margin_all(8)
	shell_panel.add_theme_stylebox_override("panel", sb)
	add_child(shell_panel)

	vbox = VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 4)
	shell_panel.add_child(vbox)

	output_label = RichTextLabel.new()
	output_label.bbcode_enabled = true; output_label.scroll_active = true
	output_label.scroll_following = true; output_label.fit_content = false
	output_label.size_flags_vertical = Control.SIZE_EXPAND_FILL
	output_label.add_theme_font_size_override("normal_font_size", fs)
	output_label.add_theme_font_size_override("bold_font_size", fs)
	output_label.add_theme_color_override("default_color", Color(0.75, 0.80, 0.75))
	vbox.add_child(output_label)

	input_line = LineEdit.new()
	input_line.placeholder_text = "type a command... (help for list)"
	input_line.add_theme_font_size_override("font_size", fs)
	input_line.add_theme_color_override("font_color", Color(0.9, 0.95, 0.9))
	input_line.add_theme_color_override("font_placeholder_color", Color(0.45, 0.45, 0.45))
	var isb := StyleBoxFlat.new()
	isb.bg_color = Color(0.08, 0.10, 0.08, 0.9)
	isb.border_color = Color(0.3, 0.4, 0.3, 0.5)
	isb.set_border_width_all(1); isb.set_corner_radius_all(3); isb.set_content_margin_all(6)
	input_line.add_theme_stylebox_override("normal", isb)
	input_line.add_theme_stylebox_override("focus", isb)
	input_line.text_submitted.connect(_on_input_submitted)
	vbox.add_child(input_line)

	_print_output("[color=#66aa66]Shell ready. Type [b]help[/b] for commands.[/color]")


func _set_shell_visible(vis: bool) -> void:
	shell_panel.visible = vis
	if sim and sim.has_method("set_input_enabled"):
		sim.set_input_enabled(not vis)
	if vis:
		input_line.grab_focus()
		Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
	else:
		input_line.release_focus()
		Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)


func _print_output(line: String) -> void:
	output_lines.append(line)
	if output_lines.size() > MAX_OUTPUT_LINES:
		output_lines = output_lines.slice(output_lines.size() - MAX_OUTPUT_LINES)
	output_label.text = "\n".join(output_lines)

func _print_error(msg: String) -> void: _print_output("[color=#ff6666]error: %s[/color]" % msg)
func _print_ok(msg: String) -> void: _print_output("[color=#88cc88]%s[/color]" % msg)
func _print_sched(msg: String) -> void: _print_output("[color=#aaaacc]%s[/color]" % msg)


func _on_input_submitted(text: String) -> void:
	var cmd := text.strip_edges(); input_line.clear()
	if cmd.is_empty(): return
	if history.is_empty() or history[history.size() - 1] != cmd:
		history.append(cmd)
		if history.size() > MAX_HISTORY: history = history.slice(history.size() - MAX_HISTORY)
	history_idx = history.size()
	_print_output("[color=#999999]> %s[/color]" % cmd)
	_exec_command(cmd, false)


func _exec_command(cmd: String, from_sched: bool) -> void:
	var parts := cmd.split(" ", false)
	if parts.is_empty(): return
	match parts[0].to_lower():
		"help": _cmd_help()
		"time": _print_ok("sim time: %.4f s" % _get_time())
		"pause", "resume": _print_ok("Use Space key (sim time: %.3f)" % _get_time())
		"reset":
			if sim and sim.has_method("reset_world"):
				sim.reset_world(); schedule_queue.clear()
				_print_ok("World reset, queue cleared.")
		"clear":
			if sim and sim.has_method("clear_neutrals"):
				sim.clear_neutrals(); _print_ok("Neutrals cleared.")
		"queue": _cmd_queue()
		"flush": schedule_queue.clear(); _print_ok("Queue cleared.")
		"cls": output_lines.clear(); output_label.text = ""
		"spawn": _cmd_spawn(parts)
		"magnet": _cmd_magnet(parts)
		"repeat": _cmd_repeat(parts)
		_: _print_error("Unknown: %s" % parts[0])


func _cmd_help() -> void:
	for l in [
		"[b]COMMANDS[/b]", "",
		"[color=#aaccaa]spawn[/color] +|-|o|N|S x,y,z vx,vy,vz [@time]",
		"[color=#aaccaa]magnet[/color] x,y,z dx,dy,dz strength [@time]",
		"[color=#aaccaa]repeat[/color] N <command>",
		"", "[color=#aaccaa]time[/color] [color=#aaccaa]queue[/color] [color=#aaccaa]flush[/color] [color=#aaccaa]reset[/color] [color=#aaccaa]clear[/color] [color=#aaccaa]cls[/color]",
		"", "[color=#666666]Vectors: x,y,z (no spaces). @time = at sim time.[/color]",
		"[color=#666666]Example: spawn + 500,500,500 100,0,0 @2.0[/color]",
	]: _print_output(l)


func _cmd_queue() -> void:
	if schedule_queue.is_empty(): _print_ok("Queue empty."); return
	_print_output("[b]Scheduled (%d):[/b]" % schedule_queue.size())
	var s := schedule_queue.duplicate()
	s.sort_custom(func(a, b): return a["time"] < b["time"])
	for i in range(mini(s.size(), 30)):
		_print_output("  @%.3f  %s" % [s[i]["time"], s[i]["cmd"]])


func _cmd_spawn(parts: PackedStringArray) -> void:
	if parts.size() < 4: _print_error("spawn <type> <pos> <vel> [@time]"); return
	var pos := _parse_vec3(parts[2]); var vel := _parse_vec3(parts[3])
	if pos == null or vel == null: _print_error("Bad vector. Use x,y,z"); return
	var st := _extract_time(parts)
	if st >= 0.0:
		var rc := "spawn %s %s %s" % [parts[1], parts[2], parts[3]]
		schedule_queue.append({"time": st, "cmd": rc})
		_print_sched("Scheduled: %s @%.3f" % [rc, st]); return
	if not sim: _print_error("No simulator."); return
	match parts[1]:
		"+": sim.add_particle(pos, vel, 1); _print_ok("Spawned + at %s" % _fv(pos))
		"-": sim.add_particle(pos, vel, -1); _print_ok("Spawned - at %s" % _fv(pos))
		"o": sim.add_particle(pos, vel, 0); _print_ok("Spawned o at %s" % _fv(pos))
		"N": sim.add_monopole(pos, vel, 1); _print_ok("Spawned N at %s" % _fv(pos))
		"S": sim.add_monopole(pos, vel, -1); _print_ok("Spawned S at %s" % _fv(pos))
		_: _print_error("Type '%s'? Use + - o N S" % parts[1])


func _cmd_magnet(parts: PackedStringArray) -> void:
	if parts.size() < 4: _print_error("magnet <pos> <dir> <str> [@time]"); return
	var pos := _parse_vec3(parts[1]); var dir := _parse_vec3(parts[2])
	if pos == null or dir == null: _print_error("Bad vector."); return
	var strength := parts[3].to_float()
	var st := _extract_time(parts)
	if st >= 0.0:
		var rc := "magnet %s %s %s" % [parts[1], parts[2], parts[3]]
		schedule_queue.append({"time": st, "cmd": rc})
		_print_sched("Scheduled: %s @%.3f" % [rc, st]); return
	if not sim or not sim.has_method("add_bar_magnet"): _print_error("No add_bar_magnet."); return
	sim.add_bar_magnet(pos, dir, strength)
	_print_ok("Magnet at %s dir %s str %.0f" % [_fv(pos), _fv(dir), strength])


func _cmd_repeat(parts: PackedStringArray) -> void:
	if parts.size() < 3: _print_error("repeat <count> <command>"); return
	var count := parts[1].to_int()
	if count <= 0 or count > 1000: _print_error("Count 1-1000."); return
	var inner := parts.slice(2)
	var bt := _extract_time(inner); if bt < 0: bt = _get_time()
	var clean := PackedStringArray()
	for p in inner:
		if not p.begins_with("@"): clean.append(p)
	var cc := " ".join(clean)
	for i in range(count):
		schedule_queue.append({"time": bt + float(i) * 0.016, "cmd": cc})
	_print_sched("Queued %d x '%s' from @%.3f" % [count, cc, bt])


func _parse_vec3(s: String) -> Variant:
	var p := s.split(","); if p.size() != 3: return null
	return Vector3(p[0].to_float(), p[1].to_float(), p[2].to_float())

func _extract_time(parts: PackedStringArray) -> float:
	for p in parts:
		if p.begins_with("@"): return p.substr(1).to_float()
	return -1.0

func _get_time() -> float:
	return sim.get_sim_time() if sim and sim.has_method("get_sim_time") else 0.0

func _fv(v: Vector3) -> String: return "(%.0f, %.0f, %.0f)" % [v.x, v.y, v.z]

func _find_simulator(node: Node) -> Node:
	if node.get_class() == "ChargeSimulator3D": return node
	for child in node.get_children():
		var f := _find_simulator(child)
		if f: return f
	return null
